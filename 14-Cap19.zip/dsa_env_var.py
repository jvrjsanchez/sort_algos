# Projeto 9 - IA Generativa e RAG Para App de Sistema Inteligente de Busca em Documentos - Backend e API
# Módulo da API Para o LLM

# Import
import os

# Nvidia API
nvidia_key = "coloque-aqui-sua-chave-api"
